# python
python projects

# dateTime module contains functionalities to deal with date ranges
cd libs

```
libs$ python3 -m unittest dateTime

----------------------------------------------------------------------
Ran 0 tests in 0.000s

OK

```
